import h5py
filename = "C:\\Users\\Jun_PC\\anaconda3\\envs\\mysite\\car\\CRNN\\weight\\LSTM+BN5--30--0.000.hdf5""

with h5py.File(filename, "r") as f:
    # List all groups
    print("Keys: %s" % f.keys())
    a_group_key = list(f.keys())[0]

    # Get the data
    data = list(f[a_group_key])
